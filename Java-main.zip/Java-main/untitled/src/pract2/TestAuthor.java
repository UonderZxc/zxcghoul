package pract2;

public class TestAuthor {
    public static void main(String[] args) {
        Author n = new Author ("Petr","petr@email.ru",'m');
        System.out.println(n);
    }
}
