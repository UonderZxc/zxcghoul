package pract5;public class Fourth {
}
