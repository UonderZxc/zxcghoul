package pract7;

import java.io.IOException;

public class main {
    public static void main(String[] args) throws IOException {
        onQueue onQueue = new onQueue();
        onDequeue dequeue = new onDequeue();
        onStack onStack = new onStack();
    }
}
